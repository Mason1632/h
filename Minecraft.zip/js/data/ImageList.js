export default {
  hotbar: "hotbar.png",
  hotbarSelected: "hotbarSelected.png",

  oakPlanks: "blockIcons/oakPlanks.png",
  oakWood: "blockIcons/oakWood.png",
  grass: "blockIcons/grass.png",
  dirt: "blockIcons/dirt.png",
  stone: "blockIcons/stone.png",
  cobblestone: "blockIcons/cobblestone.png",
  stoneBricks: "blockIcons/stoneBricks.png",
  bedrock: "blockIcons/bedrock.png",
  notblockedgames: "blockIcons/notblockedgames.png"
};