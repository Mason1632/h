export default {
  //global water level will be a random number between these numbers
  globalWaterLevelRange: [46, 52],

  //block at the bottom of the world
  bottomBoundingBlock: "bedrock",
};