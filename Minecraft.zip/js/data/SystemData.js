export default {
  GAME_VERSION: "Pre-Alpha",
  GAME_VERSION_NUMBER: "0.1.0",
  
  THREEJS_VERSION: "0.120.1",
  LODASH_VERSION: "4.17.20",
};