export default {
  fov: 75,
  aspect: 2,
  near: 0.1,
  far: 500,

  rendererData: {
    powerPreference: "high-performance",
    antialias: true,
  },
};