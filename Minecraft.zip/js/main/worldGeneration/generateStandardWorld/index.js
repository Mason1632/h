import WorldData from "/js/data/WorldData.js";
import WorldGenerationData from "/js/data/WorldGenerationData.js";


const chunkWidth = WorldData.size.chunks.width,
  chunkHeight = WorldData.size.chunks.height,
  chunkDepth = WorldData.size.chunks.depth;

function generateStandardWorld(data, progressUpdate) {
  const {
    type,
    seed,
    size,
    generateStructures,
  } = data;

  const worldBase = (function() {
    const xArray = [];
  })();

  return world;

  Math.seedrandom("hgchgcv");
  console.log(Math.random());
  console.log(Math.random());
  console.log(Math.random());
}

export default generateStandardWorld;