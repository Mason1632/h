const Game = {
  //
};

export default Game;